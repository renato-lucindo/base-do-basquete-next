# Guia de integração

## Componentes e dependências

O projeto usa React/React DOM e TypeScript. Os componentes adaptados não dependem de React Router nem dos loaders do sistema de origem. `ScrollableTable` e `ResourceState` são os originais; `ScoresheetStatisticsTable`, `SortHeader`, `SortButton`, `TeamFilter` e `ColumnPicker` usam trechos reais extraídos do ZIP. Os três helpers de table-controls foram extraídos sem mudança de lógica. Tooltip e MetricCell fazem a integração local.

Para incorporar a página, copie o modelo, os componentes adaptados, ScrollableTable/ResourceState e os estilos para a estrutura do projeto. Use App como referência da composição; adapte a chamada createRoot ao roteamento/layout existente. Preserve a ordem dos estilos: styles.css, adapted/reference-table.css e overrides.css. O HTML já empacotado pode ser usado diretamente como demonstração, mas não é o arquivo recomendado para editar a implementação.

Arquivos gerados por prepare.cjs: scoresheet-statistics-table.tsx, team-filter.tsx, column-picker.tsx, table-controls.ts, reference-table.css e fixtures.js. Alterações somente neles serão sobrescritas ao regenerar. Os originais upstream devem permanecer intactos para manter a proveniência.

## Ligar aos dados reais

Substitua o import das fixtures em model.ts por um adaptador da API. O registro visual é por **atleta e equipe**: a mesma pessoa pode ter duas linhas quando atuou por equipes diferentes. Use identificadores estáveis para pessoa/equipe/linha, evitando nomes como chaves. Forneça somente as partidas em que houve participação, em ordem cronológica; essa ordem decide a última camisa em caso de empate.

O tipo Game contém `two`, `three`, `ft`, `fouls`, `technical`, `unsportsmanlike`, `five`, `gd`, `teamPoints` (number|null) e `jersey` (number|string|null). Na fixture, two/three/ft são cestas convertidas. Preserve ausência como null: não transforme null em zero. `five` e `gd` representam a ocorrência no jogo, e não um total inferido de faltas. A forma atual do modelo usa um mapa de equipes; substitua também os acessos a esse mapa ao conectar outra fonte.

Se a API fornecer agregados, mapeie para PlayerRow e preserve cobertura independente, precisão, identificação por equipe e regras abaixo. Não some médias de partidas para obter a média da competição.

## Regras que devem permanecer

- J: número de participações. PTS = 2×two + 3×three + ft; PPJ = PTS/J.
- PP% = pontos do atleta / pontos da equipe nos mesmos jogos em que participou ×100; denominador zero ou cobertura incompleta resulta em ausência.
- Totais/Por jogo altera somente 2P,3P,LL,F,T,U. Médias usam uma casa decimal e vírgula. PTS,PPJ,PP%,J,5F,GD mantêm seu significado.
- F **já inclui T e U**. Não somar T/U novamente. Cobertura incompleta em T não invalida U nem F, e vice-versa.
- 5F e GD são contagens explícitas de partidas. Não deduzir a partir dos totais T/U.
- Zero conhecido aparece como0 (ou0,0 na média); informação incompleta aparece como —. O ranking usa valores completos, antes do arredondamento; ausentes ficam ao final e sem posição.
- Empates compartilham posição1,1,3; nomes desempatarem a exibição em ordem alfabética, mantendo a posição compartilhada.
- Camisa depois do nome, no formato #12: mais usada naquela equipe; a última em empate. Camisa0 é válida.

## Filtros e colunas

Equipes começam todas marcadas. A seleção é uma união das equipes; busca e mínimo de jogos são aplicados sobre esse conjunto. Nenhuma equipe significa nenhum resultado. Todas/Nenhuma alteram imediatamente e mantêm o painel aberto. Limpar filtros restaura todas as equipes; ranking e contagens usam o conjunto filtrado.

Colunas opcionais: Equipe e12estatísticas. Todas marca as13; Nenhuma desmarca tudo e deixa somente posição/atleta. Nenhuma substitui Restaurar padrão. Equipe pode ser ocultada sem mudar os filtros. Até600px, T/U/5F/GD começam ocultas; desktop começa com todas. Escolhas manuais permanecem durante filtros/modos/redimensionamento na sessão, sem persistência após recarga.

Ao ocultar a coluna ordenada, usar PTS decrescente ou a primeira métrica visível. Sem métrica visível, preservar a ordenação anterior. A legenda acompanha a seleção e some sem métricas. Retire também a largura das colunas ocultas; preserve o atleta fixo e as duas barras sincronizadas.

Painéis fecham por clique externo ou Escape, que devolve foco ao botão. Manter operação por teclado/toque, tooltips somente com o nome por extenso da sigla e seta somente na coluna ordenada. Não reintroduzir avatar por iniciais, ícones de informação, indicadores em todas as colunas, cores antes da equipe, sublinhado em ausentes ou status da competição.

## Conferir a integração

Compare com as capturas390/1440. Verifique todas/nenhuma/uma/várias equipes, busca e mínimo juntos, zero/ausência, médias/empates,13opções de colunas, equipe oculta, seleção vazia, teclado/toque/Escape, rolagem e legenda. Execute os testes do pacote e os testes próprios da integração. A página entregue usa exclusivamente dados fictícios.
