// Build and verify the React candidate before replacing the available prototype.
const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const { pathToFileURL } = require("node:url");
const root = path.join(__dirname, "react-prototype");
function run(file) {
  const result = spawnSync(process.execPath, [path.join(root, file)], {
    cwd: root,
    stdio: "inherit",
    env: {
      ...process.env,
      STATS_URL: pathToFileURL(path.join(root, "preview.html")).href,
    },
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}
run("prepare.cjs");
run("typecheck.cjs");
run("features.test.cjs");
run("build.cjs");
run("verify.cjs");
const candidate = fs.readFileSync(path.join(root, "preview.html"));
fs.writeFileSync(
  path.join(__dirname, "Pagina de estatisticas.html"),
  candidate,
);
for (const name of [
  "verification.json",
  "desktop-1440.png",
  "mobile-390.png",
  "mobile-empty.png",
  "ranking-3p-por-jogo.png",
  "equipes-checkboxes-1440.png",
  "equipes-checkboxes-390.png",
  "faltas-por-jogo.png",
  "colunas-1440.png",
  "colunas-390.png",
])
  fs.copyFileSync(path.join(root, name), path.join(__dirname, name));
console.log(
  "Protótipo React validado e disponibilizado em Pagina de estatisticas.html.",
);
