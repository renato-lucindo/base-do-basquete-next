# Estatísticas de atletas — entrega revisão 6

## Abrir a página

Extraia o ZIP e abra **Pagina de estatisticas.html** no navegador. Funciona offline: React, CSS e dados fictícios estão incorporados. Esse arquivo é a referência visual pronta.

## Implementar no projeto

Leia **INTEGRACAO.md**. O código React editável está em **react-prototype/**. Os componentes do ZIP de referência foram efetivamente extraídos e adaptados; os originais estão em **upstream/** e o ZIP recebido está em **referencias/**. O pacote não implementa acesso a banco, API ou autenticação.

## Reconstruir e verificar

Com Node.js22 ou superior e npm, execute na pasta extraída:

```sh
npm install
npx playwright install chromium
npm run package
```

O comando final regenera os componentes, verifica os tipos, executa cinco testes de dados, compila e executa testes de interface/acessibilidade. Somente então substitui o HTML na raiz. Para um build sem testes de navegador: `npm run prepare:source`, `npm run typecheck`, `npm test` e `npm run build`. O resultado fica em **react-prototype/preview.html**.

As versões usadas estão fixadas no package.json. Os scripts desta entrega usam dependências locais, sem caminhos absolutos do computador de origem. O pacote foi reconstruído e testado com essas versões já instaladas; uma instalação nova via registro npm não foi executada. node_modules e navegadores não fazem parte do ZIP.

## Arquivos

- `react-prototype/app.tsx`: página, estado, filtros e padrões responsivos.
- `react-prototype/model.ts`: tipos, agregações, filtros, ordenação, ranking e formatação.
- `react-prototype/adapted/`: tabela, escolha de colunas, equipes, tooltip, células e helpers.
- `react-prototype/upstream/`: seis fontes originais preservadas.
- `react-prototype/prepare.cjs`: extração e adaptação reproduzível; edite este script quando alterar componentes gerados.
- `styles.css` e `react-prototype/overrides.css`: estilos da página e integração visual.
- `react-prototype/fixtures.js`: dados fictícios gerados; `app.js` na raiz é usado somente como fonte histórica desses dados, não como renderizador.
- `verification.json` e capturas PNG: provas da entrega.
- `react-prototype/provenance.json`: origem e hashes dos componentes/HTML.
- `MANIFESTO.json`: inventário com hashes dos arquivos entregues.
- `licencas/`: licenças dos runtimes React incorporados.

Acessibilidade automática sem violações nos cenários testados não equivale a auditoria manual completa. Sem publicação ou mudança no repositório/banco do projeto.
