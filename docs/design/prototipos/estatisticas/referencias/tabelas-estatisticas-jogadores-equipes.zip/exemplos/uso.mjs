import { summarizeTeamStatistics } from '../src/statistics/sports-domain.ts';
import { perGame, percentage } from '../src/statistics/domain.ts';
console.log('Equipe:', summarizeTeamStatistics({id:1,name:'Equipe exemplo',slug:'equipe-exemplo',abbreviation:'EX',games:2,points:150,offensiveRebounds:10,defensiveRebounds:30,assists:24,twoPointMade:30,twoPointAttempted:50,threePointMade:10,threePointAttempted:25,freeThrowMade:20,freeThrowAttempted:30,efficiency:160}));
console.log('Pontos por jogo do jogador:', perGame(32,2));
console.log('Aproveitamento do jogador:', percentage(7,10));
