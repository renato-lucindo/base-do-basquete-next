# Tabelas de estatísticas de jogadores e equipes

Pacote de código para adaptação em outro projeto. Inclui componentes originais, estilos, dependências locais encontradas nos imports, cálculos, DTOs e testes de origem. Não é uma aplicação autônoma pronta para abrir. As cópias preservam o checkout local; consulte manifesto.json.

## Tabela de jogadores

- referencias/app/components/boxscore-statistics-explorer.tsx: BoxscoreStatisticsExplorer, tabela de estatísticas avançadas, seleção de equipes, colunas, filtros, comparação e modos de visualização.
- referencias/app/components/boxscore-statistics.css: estilos específicos dessa tabela.
- referencias/app/components/statistics-explorer.tsx: StatisticsExplorer, incluindo a tabela de súmula manual e o caminho estatístico anterior. ScoresheetStatisticsTable é interna ao componente, sem export isolado.
- referencias/app/modules/statistics/boxscore-statistics-domain.ts e boxscore-statistics-contract.ts: montagem dos valores, escalas, parâmetros de consulta e tratamento de amostra insuficiente.
- referencias/app/modules/statistics/table-controls.ts: controles de busca e ordenação.

## Tabela de equipes

- referencias/app/components/public-sports-core.tsx: contém TeamStatistics, com Equipe, J, PTS/J, REB/J, AST/J, FG%, 3P%, LL% e EF/J. TeamStatistics é interna; o componente exportado é PublicSportsCore e recebe context, data e resource. No código original, o ramo de equipes usa resource='equipes'. Para usar só a tabela, extraia essa função e seus imports.
- referencias/app/modules/statistics/sports-domain.ts: summarizeTeamStatistics calcula médias e percentuais a partir de totais fornecidos; calculateStandings monta a classificação.
- referencias/app/modules/statistics/public-sports.server.ts: exemplo de carregamento e seleção dos dados que alimentam a tabela.
- referencias/app/components/game-statistics.tsx: inclui tabelas de jogadores e comparação coletiva das duas equipes dentro de um jogo.
- referencias/app/components/team-profile.tsx: perfil público da equipe, complementar às tabelas.

## Estilos e dependências

referencias/app/app.css é a folha global original, com variáveis, tabelas, foco e responsividade. Selecione as regras necessárias ao destino; importar tudo pode mudar outras páginas. ScrollableTable e ResourceState estão incluídos. Os caminhos relativos locais foram percorridos, inclusive imports apenas de tipos; por isso há exemplos de backend e tipos gerados no pacote.

DEPENDENCIAS.json lista os imports externos, versões declaradas na origem e a resolução dos imports locais. Não copie o conjunto inteiro de dependências para o destino: instale apenas as necessárias aos componentes escolhidos. As interfaces usam React e React Router. Os loaders .server.ts são referências de backend e dependem de Supabase e do schema original; não os importe no frontend. O pacote não inclui um banco pronto, migrations completas, credenciais nem dados reais extraídos do banco.

## Reutilizar

1. Escolha a tabela de jogadores e/ou equipes acima.
2. Copie o componente, os cálculos e seus auxiliares, preservando os imports ou adaptando-os.
3. Adapte CompetitionContext, links contextPath e o DTO de entrada ao seu projeto.
4. Forneça dados no formato esperado e somente do contexto e fonte autoritativa corretos.
5. Aplique os estilos necessários e confira teclado, foco, rolagem, celular e estados sem dados no destino.

src/statistics/ contém uma seleção de módulos de cálculo sem dependências externas de produção, junto com os testes originais disponíveis. São cópias sem alteração de lógica.

Para uma verificação básica com Node.js 24+:

    node verificar.mjs
    node exemplos/uso.mjs

Os testes originais *.test.ts/tsx usam Vitest e requerem ambiente/dependências do destino. A verificação básica separada não renderiza as tabelas nem substitui os testes Vitest/SQL.

## Dados ausentes e identidade

Percentuais usam totais de convertidos/tentados; não faça média simples dos percentuais de jogos. Tentativas ausentes não viram zero. Médias dependem do denominador elegível da fonte; os cálculos isolados não filtram DNP, publicação nem competição.

summarizeTeamStatistics recebe números completos e não faz validação integral de entrada. Não passe zeros fictícios para estatísticas que a súmula manual não possui. normalizePer30 requer pelo menos 600 segundos cobertos no contrato original. Preserve diferenças entre null, zero, sem amostra e não jogou.

As regras são as existentes neste checkout, não uma certificação de regulamento. calculateStandings indexa as equipes por id; o adaptador deve fornecer a identidade correta de inscrição quando A/B compartilham equipe global. O resumo retornado por summarizeTeamStatistics não preserva registrationId opcional, portanto trate essa identidade explicitamente na integração.

Nenhum arquivo do repositório original foi modificado nesta exportação.

## Tipos gerados de rotas

O import ./+types/public-context, listado em DEPENDENCIAS.json, é gerado pelo React Router e não existe como fonte neste checkout. Gere os tipos no projeto de destino ou adapte a rota. Os componentes de tabela não dependem desse arquivo para serem extraídos e adaptados separadamente.
