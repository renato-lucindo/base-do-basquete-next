import { Link, NavLink, useNavigate } from "react-router";
import {
  type CompetitionContext,
  canonicalPublicResource,
  contextPath,
  genderDivisionLabel,
  PUBLIC_NAV_RESOURCES,
  type PublicResource,
} from "../modules/competition/context";
import { ContextualSearch } from "./contextual-search";

const resourceLabels: Record<PublicResource, string> = {
  "visao-geral": "Visão geral",
  classificacao: "Classificação",
  jogadores: "Jogadores",
  equipes: "Equipes",
  jogos: "Jogos",
};

interface PublicNavigationProps {
  context: CompetitionContext;
  contexts: CompetitionContext[];
  resource: PublicResource;
  detailLabel?: string;
}

function unique<T>(values: T[]): T[] {
  return [...new Set(values)];
}

function isAdultContext(context: CompetitionContext): boolean {
  return /adult|livre|senior|sênior/i.test(`${context.category.name} ${context.category.slug}`);
}

export function PublicHeader({ context, contexts, detailLabel, resource }: PublicNavigationProps) {
  const navigate = useNavigate();
  const years = unique(contexts.map((option) => option.year));
  const series = contexts.filter((option) => option.year === context.year);
  const seriesOptions = unique(series.map((option) => option.series.slug))
    .map((slug) => series.find((option) => option.series.slug === slug))
    .filter((option): option is CompetitionContext => option !== undefined);
  const categoryContexts = contexts.filter(
    (option) => option.year === context.year && option.series.slug === context.series.slug,
  );
  const categoryOptions = unique(categoryContexts.map((option) => option.category.slug))
    .map(
      (slug) =>
        categoryContexts.find(
          (option) =>
            option.category.slug === slug && option.genderDivision === context.genderDivision,
        ) ?? categoryContexts.find((option) => option.category.slug === slug),
    )
    .filter((option): option is CompetitionContext => option !== undefined);
  const genderOptions = categoryContexts.filter(
    (option) => option.category.slug === context.category.slug,
  );

  function goTo(next: CompetitionContext | undefined) {
    if (next) {
      navigate(contextPath(next, canonicalPublicResource(resource)));
    }
  }

  return (
    <header className="public-header">
      <div className="public-header-topline">
        <Link className="brand" to={contextPath(context, "classificacao")}>
          <span className="brand-mark" aria-hidden="true">
            B
          </span>
          <span>Base do Basquete</span>
        </Link>
        <ContextualSearch
          context={context}
          currentPageSupported={resource === "jogadores" && !detailLabel}
        />
        <Link className="admin-link" to="/admin">
          Administração
        </Link>
      </div>

      <nav className="public-nav" aria-label="Navegação da edição">
        <details className="context-quick-menu">
          <summary aria-label="Alterar edição">
            <span className="context-dot" aria-hidden="true" />
            <span className="context-summary-copy">
              <strong>{context.series.name}</strong>
              <small>
                {context.year} · {context.category.name} ·{" "}
                {genderDivisionLabel(context.genderDivision)}
              </small>
            </span>
          </summary>
          <div>
            <fieldset className="context-bar">
              <legend>Selecionar edição</legend>
              <label>
                <span>Competição</span>
                <select
                  aria-label="Competição"
                  value={context.series.slug}
                  onChange={(event) =>
                    goTo(
                      series.find(
                        (option) =>
                          option.series.slug === event.currentTarget.value &&
                          option.category.slug === context.category.slug &&
                          option.genderDivision === context.genderDivision,
                      ) ??
                        series.find((option) => option.series.slug === event.currentTarget.value),
                    )
                  }
                >
                  {seriesOptions.map((option) => (
                    <option key={option.series.slug} value={option.series.slug}>
                      {option.series.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                <span>Ano</span>
                <select
                  aria-label="Ano"
                  value={context.year}
                  onChange={(event) =>
                    goTo(
                      contexts.find(
                        (option) =>
                          option.year === Number(event.currentTarget.value) &&
                          option.series.slug === context.series.slug &&
                          option.category.slug === context.category.slug &&
                          option.genderDivision === context.genderDivision,
                      ) ??
                        contexts.find(
                          (option) => option.year === Number(event.currentTarget.value),
                        ),
                    )
                  }
                >
                  {years.map((year) => (
                    <option key={year} value={year}>
                      {year}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                <span>Categoria</span>
                <select
                  aria-label="Categoria"
                  value={context.category.slug}
                  onChange={(event) =>
                    goTo(
                      categoryOptions.find(
                        (option) => option.category.slug === event.currentTarget.value,
                      ),
                    )
                  }
                >
                  {categoryOptions.map((option) => (
                    <option key={option.category.slug} value={option.category.slug}>
                      {option.category.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                <span>Naipe</span>
                <select
                  aria-label="Naipe"
                  value={context.genderDivision ?? "review"}
                  onChange={(event) =>
                    goTo(
                      genderOptions.find(
                        (option) =>
                          (option.genderDivision ?? "review") === event.currentTarget.value,
                      ),
                    )
                  }
                >
                  {genderOptions.map((option) => (
                    <option key={option.competitionId} value={option.genderDivision ?? "review"}>
                      {genderDivisionLabel(option.genderDivision)}
                    </option>
                  ))}
                </select>
              </label>
            </fieldset>
            {[
              { label: "Adulto", options: contexts.filter(isAdultContext) },
              {
                label: "Categorias de base",
                options: contexts.filter((option) => !isAdultContext(option)),
              },
            ].map((group) =>
              group.options.length > 0 ? (
                <section key={group.label}>
                  <strong>{group.label}</strong>
                  {group.options.map((option) => (
                    <Link
                      aria-current={
                        option.competitionId === context.competitionId ? "page" : undefined
                      }
                      key={option.competitionId}
                      to={contextPath(option, resource)}
                    >
                      {option.year} · {option.series.name} · {option.category.name} ·{" "}
                      {genderDivisionLabel(option.genderDivision)}
                    </Link>
                  ))}
                </section>
              ) : null,
            )}
          </div>
        </details>
        <span className="public-nav-divider" aria-hidden="true" />
        {PUBLIC_NAV_RESOURCES.map((item) => (
          <NavLink
            key={item}
            to={contextPath(context, item)}
            className={({ isActive }) => (isActive ? "active" : undefined)}
            end={false}
          >
            {resourceLabels[item]}
          </NavLink>
        ))}
      </nav>
    </header>
  );
}

export function PublicBreadcrumb({ context, resource, detailLabel }: PublicNavigationProps) {
  return (
    <nav className="breadcrumb" aria-label="Caminho atual">
      <ol>
        <li>
          <Link to={contextPath(context, "classificacao")}>{context.series.name}</Link>
        </li>
        <li>
          <Link to={contextPath(context, resource)}>
            {context.year} · {context.category.name} · {genderDivisionLabel(context.genderDivision)}
          </Link>
        </li>
        <li aria-current={detailLabel ? undefined : "page"}>{resourceLabels[resource]}</li>
        {detailLabel ? <li aria-current="page">{detailLabel}</li> : null}
      </ol>
    </nav>
  );
}

export function resourceLabel(resource: PublicResource): string {
  return resourceLabels[resource];
}

export function PublicFooter() {
  return (
    <footer className="public-footer">
      <p>Dados coletados pela equipe de estatística da FECABA.</p>
      <p>Site desenvolvido por Renato Lucindo.</p>
    </footer>
  );
}
