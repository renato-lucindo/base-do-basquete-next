import { describe, expect, it, vi } from "vitest";
import type { CompetitionContext } from "../competition/context";
import { loadPublicSportsCore } from "./public-sports.server";

const context = { competitionId: 77 } as CompetitionContext;

describe("published sports snapshot", () => {
  it("uses only the current versioned snapshot and preserves missing scheduled scores", async () => {
    const from = vi.fn(() => {
      throw new Error("base tables must not be queried when a snapshot exists");
    });
    const client = {
      rpc: vi.fn().mockResolvedValue({
        data: {
          schemaVersion: 1,
          teams: [
            { id: 1, name: "Azul", slug: "azul", abbreviation: "AZL" },
            { id: 2, name: "Ouro", slug: "ouro", abbreviation: null },
          ],
          games: [
            {
              id: 9,
              label: "Jogo 9",
              status: "scheduled",
              scheduledAt: "2026-09-12T22:00:00Z",
              venue: "Ginásio",
              home: { id: 1, name: "Azul", slug: "azul", abbreviation: "AZL" },
              away: { id: 2, name: "Ouro", slug: "ouro", abbreviation: null },
              homeScore: null,
              awayScore: null,
              trackCode: "main",
              stageCode: "knockout",
              stageName: "Eliminatória simples",
              roundCode: "final",
              roundName: "Final",
              roundOrder: 2,
              matchupCode: "final_match_1",
              matchupOrder: 1,
            },
          ],
        },
        error: null,
      }),
      from,
    };
    const result = await loadPublicSportsCore(client as never, context);
    expect(client.rpc).toHaveBeenCalledWith("public_get_competition_publication", {
      p_competition_id: 77,
    });
    expect(from).not.toHaveBeenCalled();
    expect(result.games[0]).toMatchObject({
      homeScore: null,
      awayScore: null,
      structure: { roundName: "Final", matchupOrder: 1 },
    });
    expect(result.standings.every((row) => row.games === 0)).toBe(true);
    expect(result.teamStatistics.every((row) => row.reboundsPerGame === null)).toBe(true);
  });

  it("rejects an invalid snapshot without exposing its contents", async () => {
    const client = {
      rpc: vi.fn().mockResolvedValue({ data: { secret: "do not expose" }, error: null }),
      from: vi.fn(() => ({
        select: () => ({
          eq: () => ({ in: vi.fn().mockResolvedValue({ data: [], error: null }) }),
        }),
      })),
    };
    const result = await loadPublicSportsCore(client as never, context);
    expect(result).toEqual({ games: [], standings: [], teamStatistics: [], teams: [] });
  });

  it("uses the legacy read model while the publication RPC is not deployed", async () => {
    const client = {
      rpc: vi.fn().mockResolvedValue({
        data: null,
        error: { code: "PGRST202", message: "function is not in the schema cache" },
      }),
      from: vi.fn(() => ({
        select: () => ({
          eq: () => ({ in: vi.fn().mockResolvedValue({ data: [], error: null }) }),
        }),
      })),
    };
    const result = await loadPublicSportsCore(client as never, context);
    expect(result).toEqual({ games: [], standings: [], teamStatistics: [], teams: [] });
  });

  it("keeps legacy public team identity while public_name is not deployed", async () => {
    let registrationQueries = 0;
    const resultBuilder = (result: unknown) => {
      const builder = {
        eq: vi.fn(() => builder),
        in: vi.fn(() => builder),
        order: vi.fn(() => builder),
        // biome-ignore lint/suspicious/noThenProperty: Supabase query builders are intentionally thenable.
        then: (resolve: (value: unknown) => unknown, reject: (reason: unknown) => unknown) =>
          Promise.resolve(result).then(resolve, reject),
      };
      return builder;
    };
    const client = {
      rpc: vi.fn().mockResolvedValue({
        data: null,
        error: { code: "PGRST202", message: "function is not in the schema cache" },
      }),
      from: vi.fn((table: string) => ({
        select: vi.fn(() => {
          if (table === "team_registrations") {
            registrationQueries += 1;
            return resultBuilder(
              registrationQueries === 1
                ? { data: null, error: { code: "PGRST204" } }
                : { data: [{ id: 10, team_id: 1 }], error: null },
            );
          }
          if (table === "teams") {
            return resultBuilder({
              data: [{ id: 1, name: "Azul", slug: "azul", abbreviation: "AZL" }],
              error: null,
            });
          }
          if (table === "games") {
            return resultBuilder({ data: [], error: null });
          }
          throw new Error(`unexpected table: ${table}`);
        }),
      })),
    };

    const result = await loadPublicSportsCore(client as never, context);

    expect(result.teams).toEqual([{ id: 1, name: "Azul", slug: "azul", abbreviation: "AZL" }]);
  });
});
